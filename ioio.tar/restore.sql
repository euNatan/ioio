--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public.index_users_on_reset_password_token;
DROP INDEX public.index_users_on_email;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.photos DROP CONSTRAINT photos_pkey;
ALTER TABLE ONLY public.items DROP CONSTRAINT items_pkey;
ALTER TABLE ONLY public.collections DROP CONSTRAINT collections_pkey;
ALTER TABLE ONLY public.banners DROP CONSTRAINT banners_pkey;
ALTER TABLE ONLY public.articles DROP CONSTRAINT articles_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY public.administrators DROP CONSTRAINT administrators_pkey;
ALTER TABLE ONLY public.abouts DROP CONSTRAINT abouts_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.photos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.collections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.banners ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.articles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.administrators ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.abouts ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.photos_id_seq;
DROP TABLE public.photos;
DROP SEQUENCE public.items_id_seq;
DROP TABLE public.items;
DROP SEQUENCE public.collections_id_seq;
DROP TABLE public.collections;
DROP SEQUENCE public.banners_id_seq;
DROP TABLE public.banners;
DROP SEQUENCE public.articles_id_seq;
DROP TABLE public.articles;
DROP TABLE public.ar_internal_metadata;
DROP SEQUENCE public.administrators_id_seq;
DROP TABLE public.administrators;
DROP SEQUENCE public.abouts_id_seq;
DROP TABLE public.abouts;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: eunatan
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO eunatan;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: eunatan
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: abouts; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.abouts (
    id integer NOT NULL,
    title character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.abouts OWNER TO eunatan;

--
-- Name: abouts_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.abouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.abouts_id_seq OWNER TO eunatan;

--
-- Name: abouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.abouts_id_seq OWNED BY public.abouts.id;


--
-- Name: administrators; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.administrators (
    id integer NOT NULL,
    email character varying,
    password_digest character varying,
    first_name character varying,
    last_name character varying,
    remember_token character varying,
    remember_token_expires_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.administrators OWNER TO eunatan;

--
-- Name: administrators_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.administrators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.administrators_id_seq OWNER TO eunatan;

--
-- Name: administrators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.administrators_id_seq OWNED BY public.administrators.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO eunatan;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    title character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    image character varying
);


ALTER TABLE public.articles OWNER TO eunatan;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.articles_id_seq OWNER TO eunatan;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: banners; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.banners (
    id integer NOT NULL,
    title character varying,
    description text,
    active boolean,
    button character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    image character varying
);


ALTER TABLE public.banners OWNER TO eunatan;

--
-- Name: banners_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.banners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banners_id_seq OWNER TO eunatan;

--
-- Name: banners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.banners_id_seq OWNED BY public.banners.id;


--
-- Name: collections; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.collections (
    id integer NOT NULL,
    name character varying,
    description text,
    stock integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    image character varying
);


ALTER TABLE public.collections OWNER TO eunatan;

--
-- Name: collections_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.collections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.collections_id_seq OWNER TO eunatan;

--
-- Name: collections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.collections_id_seq OWNED BY public.collections.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.items (
    id integer NOT NULL,
    collection_id integer,
    user_id integer,
    descriprion text,
    status_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    code integer
);


ALTER TABLE public.items OWNER TO eunatan;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_id_seq OWNER TO eunatan;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: photos; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.photos (
    id integer NOT NULL,
    item_id integer,
    image character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.photos OWNER TO eunatan;

--
-- Name: photos_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.photos_id_seq OWNER TO eunatan;

--
-- Name: photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.photos_id_seq OWNED BY public.photos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO eunatan;

--
-- Name: users; Type: TABLE; Schema: public; Owner: eunatan
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    provider character varying,
    uid character varying,
    name character varying,
    image text
);


ALTER TABLE public.users OWNER TO eunatan;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: eunatan
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO eunatan;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: eunatan
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: abouts id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.abouts ALTER COLUMN id SET DEFAULT nextval('public.abouts_id_seq'::regclass);


--
-- Name: administrators id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.administrators ALTER COLUMN id SET DEFAULT nextval('public.administrators_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: banners id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.banners ALTER COLUMN id SET DEFAULT nextval('public.banners_id_seq'::regclass);


--
-- Name: collections id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.collections ALTER COLUMN id SET DEFAULT nextval('public.collections_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: photos id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.photos ALTER COLUMN id SET DEFAULT nextval('public.photos_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: abouts; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.abouts (id, title, description, created_at, updated_at) FROM stdin;
\.
COPY public.abouts (id, title, description, created_at, updated_at) FROM '$$PATH$$/3233.dat';

--
-- Data for Name: administrators; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.administrators (id, email, password_digest, first_name, last_name, remember_token, remember_token_expires_at, created_at, updated_at) FROM stdin;
\.
COPY public.administrators (id, email, password_digest, first_name, last_name, remember_token, remember_token_expires_at, created_at, updated_at) FROM '$$PATH$$/3243.dat';

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3227.dat';

--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.articles (id, title, description, created_at, updated_at, image) FROM stdin;
\.
COPY public.articles (id, title, description, created_at, updated_at, image) FROM '$$PATH$$/3231.dat';

--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.banners (id, title, description, active, button, created_at, updated_at, image) FROM stdin;
\.
COPY public.banners (id, title, description, active, button, created_at, updated_at, image) FROM '$$PATH$$/3235.dat';

--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.collections (id, name, description, stock, created_at, updated_at, image) FROM stdin;
\.
COPY public.collections (id, name, description, stock, created_at, updated_at, image) FROM '$$PATH$$/3239.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.items (id, collection_id, user_id, descriprion, status_id, created_at, updated_at, code) FROM stdin;
\.
COPY public.items (id, collection_id, user_id, descriprion, status_id, created_at, updated_at, code) FROM '$$PATH$$/3237.dat';

--
-- Data for Name: photos; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.photos (id, item_id, image, created_at, updated_at) FROM stdin;
\.
COPY public.photos (id, item_id, image, created_at, updated_at) FROM '$$PATH$$/3241.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3226.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: eunatan
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, provider, uid, name, image) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, provider, uid, name, image) FROM '$$PATH$$/3229.dat';

--
-- Name: abouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.abouts_id_seq', 1, true);


--
-- Name: administrators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.administrators_id_seq', 1, true);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, true);


--
-- Name: banners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.banners_id_seq', 1, true);


--
-- Name: collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.collections_id_seq', 2, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.items_id_seq', 7, true);


--
-- Name: photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.photos_id_seq', 16, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: eunatan
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: abouts abouts_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.abouts
    ADD CONSTRAINT abouts_pkey PRIMARY KEY (id);


--
-- Name: administrators administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.administrators
    ADD CONSTRAINT administrators_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: photos photos_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT photos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: eunatan
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: eunatan
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: eunatan
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- PostgreSQL database dump complete
--

